Nume: Dutu Alin Calin
Grupa: 323 CD

	Pe langa functionalitatile cerute, am zis ca ar fi necesar sa afisez si graficele
la exercitiile 1,2 si 5. Trebuie doar sa se ruleze checker-ul local si graficele
vor fi afisate automat, toate intr-o fereastra noua.

	De asemenea, daca nu iau punctajul maxim pe Vmchecker as dori reverificarea temei
folosind checker-ul local.